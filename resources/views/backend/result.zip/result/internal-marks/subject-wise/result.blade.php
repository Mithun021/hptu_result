<style>

.result-table-a4 {
    width: 100%;
    border-collapse: collapse;
    font-family: Arial, sans-serif;
}

.result-table-a4 th,
.result-table-a4 td {
    border: 1px solid #ddd;
    padding: 8px;
    font-size: 12px;
    text-align: center;
}

/* Table Header */
.result-table-a4 thead th {
    background: #f5f5f5;
    font-weight: 600;
}

/* Table Footer */
.result-table-a4 tfoot td {
    font-weight: 600;
    padding: 25px 8px 10px;
    text-align: center;
    vertical-align: bottom;
}

/* Footer top spacing for signature */
.result-table-a4 tfoot td::before {
    content: "";
    display: block;
    height: 40px;
}

/* Header section styling */
.result-header h4 {
    margin: 2px 0;
}

.result-header p {
    margin: 4px 0;
    text-align: left
}

</style>

<div class="table-responsive">

<table class="result-table-a4">

    <!-- ===============================
            RESULT HEADER
    ================================ -->

    <thead>

        <tr>
            <td colspan="4" class="result-header">

                <center>
                    <h4>CONTROLLER OF EXAMINATIONS</h4>

                    <h4>
                        GURU ANGAD DEV VETERINARY AND ANIMAL SCIENCE UNIVERSITY,
                        LUDHIANA (INDIA)
                    </h4>

                    <h4>{{ $className }} Session {{ $batch->name ?? '_' }}</h4>

                    <h4>{{ $midsemexam->mid_sem_exam_name }}</h4>
                </center>

                <p>
                    <b>{{ $course->name }} ({{ $branch->name ?? '' }})</b>
                </p>

                <p>
                    Subject : {{ $subject->name }} ({{ $subject->subject_code }})
                </p>

                <p>
                    Maximum Marks :

                    @if($marksType == 'Mid-Sem')
                        {{ $subject->mid_sem_marks1 }}

                    @elseif($marksType == 'Quiz')
                        {{ $subject->mid_sem_marks2 }}

                    @elseif($marksType == 'Practical')
                        {{ $subject->mid_sem_marks3 }}
                        
                    @elseif($marksType == 'Internal 1')

                        {{ $subject->internal1 }}

                    @elseif($marksType == 'Internal 2')

                        {{ $subject->internal2 }}

                    @elseif($marksType == 'Internal 3')

                        {{ $subject->internal3 }}

                    @else
                        -
                    @endif

                </p>

            </td>
        </tr>


        <!-- ===============================
                TABLE COLUMN HEADER
        ================================ -->

        <tr>
            <th>Admission Number / Roll No</th>
            <th>Student Name</th>
            <th>Max Marks</th>
            <th>Obtained Marks</th>
        </tr>

    </thead>


    <!-- ===============================
            STUDENT DATA
    ================================ -->

    <tbody>

        @forelse($students as $student)

            <tr>

                <!-- Admission / Roll -->
                <td>
                    {{ $student->admission_no ?? $student->university_roll_no }}
                </td>

                <!-- Student Name -->
                <td>
                    {{ $student->student_name }}
                </td>

                <!-- Max Marks -->
                <td>

                    @if($marksType == 'Mid-Sem')

                        {{ $subject->mid_sem_marks1 }}

                    @elseif($marksType == 'Quiz')

                        {{ $subject->mid_sem_marks2 }}

                    @elseif($marksType == 'Practical')

                        {{ $subject->mid_sem_marks3 }}

                    @elseif($marksType == 'Internal 1')

                        {{ $subject->internal1 }}

                    @elseif($marksType == 'Internal 2')

                        {{ $subject->internal2 }}

                    @elseif($marksType == 'Internal 3')

                        {{ $subject->internal3 }}

                    @else

                        -

                    @endif

                </td>

                <!-- Obtained Marks -->
                {{-- <td>

                    @if(array_key_exists($student->id, $marks))

                        @if($marks[$student->id] == 'AB')

                            <span style="color:red;font-weight:600;">AB</span>

                        @else

                            {{ $marks[$student->id] }}

                        @endif

                    @else

                        <span style="color:#999;">Marks Not Uploaded</span>

                    @endif

                </td> --}}
                
                <!-- Obtained Marks -->
                <td>

                    @php
                        // ✅ ADDED
                        $isEnrolled = in_array($student->id, $studentSubjects);
                    @endphp

                    @if(!$isEnrolled)
                        {{-- ✅ NOT ENROLLED --}}
                        <span style="color:#999;">NA</span>

                    @elseif(array_key_exists($student->id, $marks))

                        @if($marks[$student->id] == 'AB')
                            <span style="color:red;font-weight:600;">AB</span>
                        @else
                            {{ $marks[$student->id] }}
                        @endif

                    @else

                        <span style="color:#df610d;">Marks Not Uploaded</span>

                    @endif

                </td>

            </tr>

        @empty

            <tr>
                <td colspan="4">
                    <span style="color:red;">No Students Found</span>
                </td>
            </tr>

        @endforelse

    </tbody>
    <tfoot>
        <tr>
            <td colspan="2">
                    Instructor(s)
            </td>
            <td colspan="2">
                    HOD
            </td>
        </tr>
    </tfoot>

</table>

</div>