<style>
.result-table {
    width: 100%;
    margin: auto;
    font-family: "Times New Roman", serif;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    border: 1px solid #000;
    padding: 4px;
    text-align: center;
    font-size: 12px;
}

th {
    background: #e6e6e6;
    font-weight: bold;
}

td.left { text-align: left; }

.fail { color: red; font-weight: bold; }
.pass { color: green; font-weight: bold; }
.remarks { text-align: left; }
</style>

<table class="result-table">

<thead>

<tr>
    <th colspan="{{ 3 + count($subjects) + 4 }}">
        <h3>OFFICE OF CONTROLLER OF EXAMINATIONS</h3>
        <h4>GURU ANGAD DEV VETERINARY AND ANIMAL SCIENCES UNIVERSITY</h4>
        <h4>{{ $exam->exam_resultsheet_name ?? $exam->name }}</h4>
    </th>
</tr>

<tr>
    <th rowspan="2">Sr. No.</th>
    <th rowspan="2">Student Name</th>
    <th rowspan="2">Admission No.</th>

    <th colspan="{{ count($subjects) }}">Subjects</th>

    <th rowspan="2">Remarks</th>
    <th rowspan="2">GPA</th>
    <th rowspan="2">CGPA</th>
    <th rowspan="2">Grade</th>
</tr>

<tr>
    @foreach($subjects as $sub)
        <th>{{ $sub->subject_code }}</th>
    @endforeach
</tr>

</thead>

<tbody>

    @foreach($students as $key => $student)

    @php
        $remarks = [];
        $totalCredit = 0;
        $totalGP = 0;

        $failCount = 0; // fail count
        $subjectResults = [];
    @endphp

    @foreach($subjects as $sub)

    @php
        $isEnrolled = isset($studentSubjects[$student->id]) &&
            $studentSubjects[$student->id]->contains('subject_id', $sub->id);

        $hasMid = isset($midSemMarks[$student->id][$sub->id]);
        // $hasEnd = isset($endSemMarks[$student->id][$sub->id]);
        $hasEnd =
        isset($endSemMarks[$student->id][$sub->id]) &&
        count($endSemMarks[$student->id][$sub->id]) > 0;

        $value = '-';
        $class = '';
    @endphp

    @if($sub->is_nc == 1)

        @php
            $external = $endSemMarks[$student->id][$sub->id]['external'][0] ?? null;
            $gradeValue = $external->grade ?? '-';

            $value = $gradeValue;

            if(strtolower($gradeValue) == 'fail'){
                $class = 'fail';
                $failCount++;
                $remarks[] = "Fail {$sub->subject_code}";
            } else {
                $class = 'pass';
            }
        @endphp

    @else

        @php
        if ($isEnrolled && ($hasMid || $hasEnd)) {

            $i1 = $midSemMarks[$student->id][$sub->id]['Internal 1'][0]->obtained_marks ?? 0;
            $i2 = $midSemMarks[$student->id][$sub->id]['Internal 2'][0]->obtained_marks ?? 0;
            $i3 = $midSemMarks[$student->id][$sub->id]['Internal 3'][0]->obtained_marks ?? 0;

            $arr = [$i1, $i2, $i3];
            rsort($arr);

            $internal = ($arr[0] ?? 0) + ($arr[1] ?? 0);

            $t1 = $endSemMarks[$student->id][$sub->id]['theory_paper1'][0]->obtained_marks ?? 0;
            $t2 = $endSemMarks[$student->id][$sub->id]['theory_paper2'][0]->obtained_marks ?? 0;

            $p1 = $endSemMarks[$student->id][$sub->id]['practical_paper1'][0]->obtained_marks ?? 0;
            $p2 = $endSemMarks[$student->id][$sub->id]['practical_paper2'][0]->obtained_marks ?? 0;

            // $total = $internal + $t1 + $t2 + $p1 + $p2;

                        /*
            =====================================
            ADJUSTMENT MARKS
            =====================================
            */

            $theoryAdjustment =
                $academicAdjustments[$student->id][$sub->id]['theory_paper1'][0]->adjustment_marks ?? 0;

            $theoryAdjustment2 =
                $academicAdjustments[$student->id][$sub->id]['theory_paper2'][0]->adjustment_marks ?? 0;

            $practicalAdjustment1 =
                $academicAdjustments[$student->id][$sub->id]['practical_paper1'][0]->adjustment_marks ?? 0;

            $practicalAdjustment2 =
                $academicAdjustments[$student->id][$sub->id]['practical_paper2'][0]->adjustment_marks ?? 0;

            /*
            =====================================
            FINAL EXTERNAL MARKS
            =====================================
            */

            $t1 += $theoryAdjustment;
            $t2 += $theoryAdjustment2;

            $p1 += $practicalAdjustment1;
            $p2 += $practicalAdjustment2;

            /*
            =====================================
            TOTAL
            =====================================
            */

            $total = $internal + $t1 + $t2 + $p1 + $p2;



            $internalMaxArr = [
                $sub->internal1 ?? 0,
                $sub->internal2 ?? 0,
                $sub->internal3 ?? 0
            ];
            rsort($internalMaxArr);

            $max =
                ($internalMaxArr[0] ?? 0) +
                ($internalMaxArr[1] ?? 0) +
                ($sub->paper1 ?? 0) +
                ($sub->paper2 ?? 0) +
                ($sub->practical_paper1 ?? 0) +
                ($sub->practical_paper2 ?? 0);

            $required = ($max * $overallPassPercent) / 100;

            if ($total >= $required) {
                $value = number_format($total / 10, 3);
                $class = 'pass';
            } else {
                $value = 'Fail';
                $class = 'fail';
                $failCount++;
                $remarks[] = "Fail {$sub->subject_code}";
            }

            $credit = $sub->credits ?? 0;
            $totalCredit += $credit;

            if (is_numeric($value)) {
                $totalGP += ($value * $credit);
            }
        }
        @endphp

    @endif

    @php
        $subjectResults[$sub->id] = [
            'value' => $value,
            'class' => $class
        ];
    @endphp

    @endforeach


    <tr>
        <td>{{ $key + 1 }}</td>
        <td class="left">{{ $student->student_name }}</td>
        <td>{{ $student->university_roll_no }}</td>

    @foreach($subjects as $sub)

    @php
        $res = $subjectResults[$sub->id];
        $value = $res['value'];
        $class = $res['class'];

        if ($class == 'fail' && $failCount <= 2) {
            $value = 'Supple';
            $class = 'fail';
        }
    @endphp

    <td class="{{ $class }}">
        <a href="javascript:void(0);"
        class="result-detail-btn"
        data-student_id="{{ $student->id }}"
        data-subject_id="{{ $sub->id }}"
        style="text-decoration:none; color:inherit; font-weight:bold;">
            {{ $value }}
        </a>
    </td>

    @endforeach

    @php
        $gpa = $totalCredit > 0
            ? number_format($totalGP / $totalCredit, 3)
            : 0;

        $cgpa = $gpa;

        $grade = '';
        foreach($grades as $g){
            if($cgpa >= $g->percent_from && $cgpa <= $g->percent_upto){
                $grade = $g->grade_description;
                break;
            }
        }
    @endphp

    <td class="remarks">
        @if(count($remarks))
            @if($failCount <= 2)
                {{ str_replace('Fail', 'Supple', implode(', ', $remarks)) }}
            @else
                {{ implode(', ', $remarks) }}
            @endif
        @else
            <span class="pass">Pass</span>
        @endif
    </td>

    <td>{{ $gpa }}</td>
    <td>{{ $cgpa }}</td>
    <td>{{ $grade }}</td>

    </tr>

    @endforeach

    </tbody>

    <tfoot>
        <tr>
            <td colspan="{{ 3 + count($subjects) + 4 }}">

                <table width="100%" style="border:none;">
                    <tr>

                        <td width="33.33%" style="border:none; text-align:left; font-size:12px;">
                            Prepared By
                            <br><br><br>
                            Checked By
                        </td>

                        <td width="33.33%" style="border:none; text-align:center; font-size:12px;">
                            Controller of Examinations
                        </td>

                        <td width="33.33%" style="border:none; text-align:right; font-size:12px;">
                            Registrar,<br>
                            Guru Angad Dev Veterinary and Animal Science University
                        </td>

                    </tr>
                </table>

            </td>
        </tr>
    </tfoot>

</table>

<div style="text-align:center; margin-top:20px;">
    <button id="saveResultSheet" class="btn btn-success">
        Save Result Sheet
    </button>
</div>

<script>
$(document).on('click', '#saveResultSheet', function () {

    let btn = $(this);

    // ✅ Confirmation Alert
    Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to save this result sheet?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {

        if (!result.isConfirmed) return;

        btn.prop('disabled', true); // disable button

        let data = {
            exam_id: "{{ $exam->id }}",
            course_type: "{{ $courseType ?? '' }}",
            course_id: "{{ $course->id }}",
            branch_id: "{{ $branch->id }}",
            batch_id: "{{ $batch->id }}",
            scheme_id: "{{ $schemeId ?? '' }}",
            semester_id: "{{ $semesterId ?? '' }}",
            annual_semester_id: "{{ $annualSemesterId ?? '' }}",
            institute_id: "{{ $instituteId ?? '' }}",
            _token: "{{ csrf_token() }}"
        };

        // 🔄 Loading
        Swal.fire({
            title: 'Please wait...',
            text: 'Saving result sheet...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: "{{ route('results.save.result.sheet') }}",
            method: "POST",
            data: data,

            success: function (res) {

                Swal.fire({
                    icon: 'success',
                    title: 'Saved!',
                    text: 'Result saved successfully',
                    timer: 2000,
                    showConfirmButton: false
                });

                btn.prop('disabled', false);
            },

            error: function (err) {

                Swal.fire({
                    icon: 'error',
                    title: 'Oops!',
                    text: 'Error saving result'
                });

                btn.prop('disabled', false);
            }
        });

    });
});
</script>