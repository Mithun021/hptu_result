<style>
.result-container {
    width: 100%;
    margin: auto;
    font-family: Arial, Helvetica, sans-serif;
}

.result-header {
    text-align: center;
    margin-bottom: 10px;
}

.result-header h3 {
    margin: 0;
    font-size: 18px;
    font-weight: bold;
}

.result-header h4 {
    margin: 2px 0;
    font-size: 16px;
}

.result-header p {
    margin: 4px 0;
    font-size: 14px;
}

.course-info {
    display: flex;
    justify-content: space-between;
    margin-bottom: 6px;
    font-size: 12px;
}

.result-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
}

.result-table th,
.result-table td {
    border: 1px solid #000;
    padding: 6px;
    text-align: center;
}

.result-table th {
    background: #f2f2f2;
    font-weight: bold;
}

.result-table td.student-name {
    text-align: left;
}

td.align-left {
    text-align: left;
}

td.align-right {
    text-align: right;
}
</style>

@php

/*
=====================================
PASS PERCENTAGE
=====================================
*/

$overallPassPercent = $passPercentage->overall_pass_percentage ?? 50;

/*
=====================================
MAX MARKS
=====================================
*/

$internalMarksArray = [
    $subject->internal1 ?? 0,
    $subject->internal2 ?? 0,
    $subject->internal3 ?? 0,
];

rsort($internalMarksArray);

$internalFirstMax  = $internalMarksArray[0] ?? 0;
$internalSecondMax = $internalMarksArray[1] ?? 0;

$theoryPaper1Max = $subject->paper1 ?? 0;
$theoryPaper2Max = $subject->paper2 ?? 0;

$theoryTotalMax = $theoryPaper1Max + $theoryPaper2Max;

$grossTheoryMax = $internalFirstMax + $internalSecondMax + $theoryTotalMax;

$practicalPaper1Max = $subject->practical_paper1 ?? 0;
$practicalPaper2Max = $subject->practical_paper2 ?? 0;

$practicalTotalMax = $practicalPaper1Max + $practicalPaper2Max;

$grandTotalMax = $grossTheoryMax + $practicalTotalMax;

/*
=====================================
PASS MARKS
=====================================
*/

$requiredMarks = ($grandTotalMax * $overallPassPercent) / 100;

@endphp

<table class="result-table result-table-a4">

<thead>

<tr>

<td colspan="16" class="result-header">

    <center>

        <h3>
            OFFICE OF CONTROLLER OF EXAMINATIONS
        </h3>

        <h4>
            GURU ANGAD DEV VETERINARY AND ANIMAL SCIENCES UNIVERSITY,
            LUDHIANA (INDIA)
        </h4>

        <h4>
            {{ $exam->exam_resultsheet_name ?? $exam->name }}
        </h4>

    </center>

    <div class="course-info">

        <div>

            <strong>Class :</strong>

            ({{ $className }}) -
            ({{ $course->name ?? '' }})

            @if(!empty($branch->name) && $branch->name != 'NA')
                ({{ $branch->name }})
            @endif

        </div>

        <div>

            <strong>Subject :</strong>

            {{ $subject->name }}
            ({{ $subject->subject_code }})

        </div>

    </div>

</td>

</tr>

<tr>

    <td rowspan="2">Sr.No.</td>

    <td rowspan="2">Admission No</td>

    <td rowspan="2">Student Name</td>

    <td colspan="2">
        Internal<br>Assisment
    </td>

    <td colspan="4">
        Theory
    </td>

    <td colspan="3">
        Practical
    </td>

    <td rowspan="2">
        Gross <br>Total<br>
        ({{ number_format($grandTotalMax, 0) }})
    </td>

    <td rowspan="2">
        Grade <br>Point
    </td>

    <td rowspan="2">
        Credit <br>Point
    </td>

    <td rowspan="2">
        Overall <br>Standing
    </td>

</tr>

<tr>

    <td>
        First<br>
        ({{ number_format($internalFirstMax, 0) }})
    </td>

    <td>
        Second<br>
        ({{ number_format($internalSecondMax, 0) }})
    </td>

    <td>
        Paper<br>(A)<br>
        [{{ number_format($theoryPaper1Max, 0) }}]
    </td>

    <td>
        Paper<br>(B)<br>
        [{{ number_format($theoryPaper2Max, 0) }}]
    </td>

    <td>
        Paper<br>(A+B)<br>
        [{{ number_format($theoryTotalMax, 0) }}]
    </td>

    <td>
        Gross Total<br>
        [{{ number_format($grossTheoryMax, 0) }}]
    </td>

    <td>
        Paper<br>(A)<br>
        [{{ number_format($practicalPaper1Max, 0) }}]
    </td>

    <td>
        Paper<br>(B)<br>
        [{{ number_format($practicalPaper2Max, 0) }}]
    </td>

    <td>
        Paper<br>(A+B)<br>
        [{{ number_format($practicalTotalMax, 0) }}]
    </td>

</tr>

</thead>

<tbody>

@foreach($students as $key => $student)

@php

/*
=====================================
ENROLLMENT + MARKS CHECK
=====================================
*/

$isEnrolled = in_array($student->id, $studentSubjects);

$hasMid = isset($midSemMarks[$student->id]);

$hasEnd = isset($endSemMarks[$student->id]);

$hasAnyMark = $hasMid || $hasEnd;

@endphp

@if(!$isEnrolled || !$hasAnyMark)

<tr>

    <td>{{ $key + 1 }}</td>

    <td>{{ $student->university_roll_no }}</td>

    <td class="student-name">
        {{ $student->student_name }}
    </td>

    <td>-</td>
    <td>-</td>

    <td>-</td>
    <td>-</td>
    <td>-</td>
    <td>-</td>

    <td>-</td>
    <td>-</td>
    <td>-</td>

    <td>-</td>
    <td>-</td>
    <td>-</td>
    <td>-</td>

</tr>

@else

@php

/*
=====================================
INTERNAL
=====================================
*/

$internal1 =
    $midSemMarks[$student->id]['Internal 1'][0]->obtained_marks ?? 0;

$internal2 =
    $midSemMarks[$student->id]['Internal 2'][0]->obtained_marks ?? 0;

$internal3 =
    $midSemMarks[$student->id]['Internal 3'][0]->obtained_marks ?? 0;

$internalMarks = [
    $internal1,
    $internal2,
    $internal3
];

rsort($internalMarks);

$bestInternal1 = $internalMarks[0] ?? 0;

$bestInternal2 = $internalMarks[1] ?? 0;

$internalTotal = $bestInternal1 + $bestInternal2;

/*
=====================================
THEORY
=====================================
*/

// $theoryPaper1 =
//     $endSemMarks[$student->id]['theory_paper1'][0]->obtained_marks ?? 0;

// $theoryPaper2 =
//     $endSemMarks[$student->id]['theory_paper2'][0]->obtained_marks ?? 0;

// $theoryTotal = $theoryPaper1 + $theoryPaper2;

/*
=====================================
THEORY
=====================================
*/

$theoryPaper1Original =
    $endSemMarks[$student->id]['theory_paper1'][0]->obtained_marks ?? 0;

$theoryPaper2Original =
    $endSemMarks[$student->id]['theory_paper2'][0]->obtained_marks ?? 0;

/*
=====================================
GRACE MARKS
=====================================
*/

$theoryPaper1Grace =
    $adjustmentMarks[$student->id]['theory_paper1'] ?? 0;

$theoryPaper2Grace =
    $adjustmentMarks[$student->id]['theory_paper2'] ?? 0;

/*
=====================================
FINAL THEORY MARKS
=====================================
*/

$theoryPaper1 =
    $theoryPaper1Original + $theoryPaper1Grace;

$theoryPaper2 =
    $theoryPaper2Original + $theoryPaper2Grace;

$theoryTotal = $theoryPaper1 + $theoryPaper2;

/*
=====================================
GROSS THEORY
=====================================
*/

$grossTheory = $internalTotal + $theoryTotal;

/*
=====================================
PRACTICAL
=====================================
*/

// $practicalPaper1 =
//     $endSemMarks[$student->id]['practical_paper1'][0]->obtained_marks ?? 0;

// $practicalPaper2 =
//     $endSemMarks[$student->id]['practical_paper2'][0]->obtained_marks ?? 0;

// $practicalTotal = $practicalPaper1 + $practicalPaper2;

/*
=====================================
PRACTICAL
=====================================
*/

$practicalPaper1Original =
    $endSemMarks[$student->id]['practical_paper1'][0]->obtained_marks ?? 0;

$practicalPaper2Original =
    $endSemMarks[$student->id]['practical_paper2'][0]->obtained_marks ?? 0;

/*
=====================================
GRACE MARKS
=====================================
*/

$practicalPaper1Grace =
    $adjustmentMarks[$student->id]['practical_paper1'] ?? 0;

$practicalPaper2Grace =
    $adjustmentMarks[$student->id]['practical_paper2'] ?? 0;

/*
=====================================
FINAL PRACTICAL MARKS
=====================================
*/

$practicalPaper1 =
    $practicalPaper1Original + $practicalPaper1Grace;

$practicalPaper2 =
    $practicalPaper2Original + $practicalPaper2Grace;

$practicalTotal = $practicalPaper1 + $practicalPaper2;

/*
=====================================
GRAND TOTAL
=====================================
*/

$grandTotal = $grossTheory + $practicalTotal;

/*
=====================================
GRADE POINT
=====================================
*/

$gradePoint = round($grandTotal / 10, 2);

/*
=====================================
RESULT
=====================================
*/

if ($grandTotal >= $requiredMarks) {

    $resultStatus = 'PASS';
    $resultColor  = 'green';

} else {

    $resultStatus = 'FAIL';
    $resultColor  = 'red';
}

/*
=====================================
CREDIT POINT
=====================================
*/

if ($resultStatus == 'PASS') {

    $creditPoint = number_format(
        ($gradePoint * ($subject->credits ?? 0)),
        2
    );

} else {

    $creditPoint = 'FAIL';
}

@endphp

<tr>

    <td>{{ $key + 1 }}</td>

    <td>{{ $student->university_roll_no }}</td>

    <td class="student-name">
        {{ $student->student_name }}
    </td>

    <td>{{ number_format($bestInternal1, 2) }}</td>

    <td>{{ number_format($bestInternal2, 2) }}</td>

    <td>
        {{ number_format($theoryPaper1, 2) }}
        @if($theoryPaper1Grace > 0)
            <br>
            <small>
                ({{ $theoryPaper1Original }} + {{ $theoryPaper1Grace }})
            </small>

        @endif
    </td>

    <td>
        {{ number_format($theoryPaper2, 2) }}
        @if($theoryPaper2Grace > 0)

            <br>

            <small>
                ({{ $theoryPaper2Original }} + {{ $theoryPaper2Grace }})
            </small>

        @endif
    </td>

    <td>{{ number_format($theoryTotal, 2) }}</td>

    <td>{{ number_format($grossTheory, 2) }}</td>

    <td>
        {{ number_format($practicalPaper1, 2) }}
        @if($practicalPaper1Grace > 0)

            <br>

            <small>
                ({{ $practicalPaper1Original }} + {{ $practicalPaper1Grace }})
            </small>

        @endif
    </td>

    <td>
        {{ number_format($practicalPaper2, 2) }}
        @if($practicalPaper2Grace > 0)

            <br>

            <small>
                ({{ $practicalPaper2Original }} + {{ $practicalPaper2Grace }})
            </small>

        @endif
    </td>

    <td>{{ number_format($practicalTotal, 2) }}</td>

    <td>
        <strong>
            {{ number_format($grandTotal, 2) }}
        </strong>
    </td>

    <td>
        {{ number_format($gradePoint, 3) }}
    </td>

    <td>
        {{ $creditPoint }}
    </td>

    <td>
        {{ $creditPoint }} <br>
        <small><strong style="color:{{ $resultColor }}">
            {{ $resultStatus }}
        </strong></small>

    </td>

</tr>

@endif

@endforeach

</tbody>

<tfoot>

<tr>

<td colspan="5" class="align-left">

    Prepared by

    <br><br><br>

    Checked by

</td>

<td colspan="5">

    Controller of Examinations

</td>

<td colspan="6" class="align-right">

    Registrar, Guru Angad Dev Veterinary <br>
    and Animal Science University

</td>

</tr>

</tfoot>

</table>