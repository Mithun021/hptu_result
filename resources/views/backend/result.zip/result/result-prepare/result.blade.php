<style>
.result-container {
    width: 100%;
    margin: auto;
    font-family: Arial, Helvetica, sans-serif;
}

.result-header {
    text-align: center;
    margin-bottom: 10px;
}

.result-header h3 {
    margin: 0;
    font-size: 18px;
    font-weight: bold;
}

.result-header h4 {
    margin: 2px 0;
    font-size: 16px;
}

.result-header p {
    margin: 4px 0;
    font-size: 14px;
}

.course-info {
    display: flex;
    justify-content: space-between;
    margin-bottom: 6px;
    font-size: 12px;
}

.result-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
}

.result-table th,
.result-table td {
    border: 1px solid #000;
    padding: 6px;
    text-align: center;
}

.result-table th {
    background: #f2f2f2;
    font-weight: bold;
}

.result-table td.student-name {
    text-align: left;
}

td.align-left {
    text-align: left;
}

td.align-right {
    text-align: right;
}

</style>

@php

/*
=====================================
SUBJECT MAX MARKS
=====================================
*/

if ($subject->type == "Theory") {

    $theoryMidMax   = $subject->mid_sem_marks1;
    $theoryQuizMax  = $subject->mid_sem_marks2;
    $theoryFinalMax = $subject->external_marks;

    $practicalMidMax   = 0;
    $practicalQuizMax  = 0;
    $practicalFinalMax = $subject->mid_sem_marks3;

} else {

    $theoryMidMax   = 0;
    $theoryQuizMax  = 0;
    $theoryFinalMax = 0;

    $practicalMidMax   = $subject->mid_sem_marks1;
    $practicalQuizMax  = $subject->mid_sem_marks2;
    $practicalFinalMax = $subject->mid_sem_marks3;
}

$theoryTotalMax    = $theoryMidMax + $theoryQuizMax + $theoryFinalMax;
$practicalTotalMax = $practicalMidMax + $practicalQuizMax + $practicalFinalMax;
$grandTotalMax     = $theoryTotalMax + $practicalTotalMax;

/*
=====================================
PASS RULE
=====================================
*/

$overallPassPercent = $passPercentage->overall_pass_percentage ?? 50;
$theoryMinPercent   = $passPercentage->theory_min_percentage ?? 20;

$requiredMarks = ($grandTotalMax * $overallPassPercent) / 100;
$theoryMinMarks = ($theoryFinalMax * $theoryMinPercent) / 100;

@endphp


<table class="result-table result-table-a4">

<thead>

<tr>
<td colspan="13" class="result-header">
    <center>
        <h3>OFFICE OF CONTROLLER OF EXAMINATIONS</h3>
        <h4>GURU ANGAD DEV VETERINARY AND ANIMAL SCIENCES UNIVERSITY, LUDHIANA (INDIA)</h4>
        <h4>{{ $exam->exam_resultsheet_name ?? $exam->name }}</h4>
    </center>

    <div class="course-info">
        <div>
            <strong>Class :</strong>
            ({{ $className }}) -
            ({{ $course->name ?? '' }})
            @if(!empty($branch->name) && $branch->name != 'NA')
                ({{ $branch->name }})
            @endif
        </div>

        <div>
            <strong>Subject :</strong>
            {{ $subject->name }} ({{ $subject->subject_code }})
        </div>
    </div>
</td>
</tr>

<tr>
<th rowspan="3">Sr No</th>
<th rowspan="3">Student Name</th>
<th rowspan="3">Admission No</th>
<th rowspan="3">CP</th>

<th colspan="3">Theory</th>
<th rowspan="2">Total</th>

<th colspan="3">Practical</th>
<th rowspan="2">Total</th>

<th rowspan="2">G Total</th>
</tr>

<tr>
<th>Mid Sem</th>
<th>Quiz</th>
<th>Final</th>

<th>Mid Sem</th>
<th>Quiz</th>
<th>Final</th>
</tr>

<tr>
<th>{{ number_format($theoryMidMax, 2) }}</th>
<th>{{ number_format($theoryQuizMax, 2) }}</th>
<th>{{ number_format($theoryFinalMax, 2) }}</th>
<th>{{ number_format($theoryTotalMax, 2) }}</th>

<th>{{ number_format($practicalMidMax, 2) }}</th>
<th>{{ number_format($practicalQuizMax, 2) }}</th>
<th>{{ number_format($practicalFinalMax, 2) }}</th>
<th>{{ number_format($practicalTotalMax, 2) }}</th>
<th>{{ number_format($grandTotalMax, 2) }}</th>
</tr>

</thead>

<tbody>

@foreach($students as $key => $student)

@php
    // ✅ Enrollment check
    $isEnrolled = in_array($student->id, $studentSubjects);

    // ✅ Marks existence check
    $hasMid = isset($midSemMarks[$student->id]);
    $hasEnd = isset($endSemMarks[$student->id]);

    $hasAnyMark = $hasMid || $hasEnd;
@endphp

@if(!$isEnrolled || !$hasAnyMark)

    {{-- ✅ NOT ENROLLED OR NO MARKS → FULL DASH --}}
    <tr>
        <td>{{ $key + 1 }}</td>
        <td class="student-name">{{ $student->student_name }}</td>
        <td>{{ $student->university_roll_no }}</td>

        <td>-</td>

        <td>-</td>
        <td>-</td>
        <td>-</td>
        <td>-</td>

        <td>-</td>
        <td>-</td>
        <td>-</td>
        <td>-</td>

        <td>-</td>
    </tr>

@else

    {{-- ✅ ORIGINAL LOGIC (SAFE VERSION) --}}
    @php

    $courseTypeName = $course->course;

    $mid   = $midSemMarks[$student->id]['Mid-Sem'][0]->obtained_marks ?? 0;
    $quiz  = $midSemMarks[$student->id]['Quiz'][0]->obtained_marks ?? 0;
    $pracFromMid = $midSemMarks[$student->id]['Practical'][0]->obtained_marks ?? 0;

    // $endFinal = $endSemMarks[$student->id]->obtained_marks ?? 0;
    /*
    =====================================
    END SEM ORIGINAL
    =====================================
    */

    $endFinalOriginal =
        $endSemMarks[$student->id]->obtained_marks ?? 0;

    /*
    =====================================
    GRACE MARKS
    =====================================
    */

    $endFinalGrace =
        $adjustmentMarks[$student->id]['external'] ?? 0;

    /*
    =====================================
    FINAL MARKS
    =====================================
    */

    $endFinal = $endFinalOriginal + $endFinalGrace;

    if ($subject->type == "Theory") {

        $final = $endFinal;
        $theoryTotal = $mid + $quiz + $final;

        $practicalMid = 0;
        $practicalQuiz = 0;

        $practicalFinal = ($courseTypeName == "UG") ? $pracFromMid : $endFinal;
        $practicalTotal = $practicalFinal;

    } else {

        $mid = $quiz = $final = 0;
        $theoryTotal = 0;

        $practicalMid  = $midSemMarks[$student->id]['Mid-Sem'][0]->obtained_marks ?? 0;
        $practicalQuiz = $midSemMarks[$student->id]['Quiz'][0]->obtained_marks ?? 0;

        $practicalFinal = ($courseTypeName == "UG") ? $pracFromMid : $endFinal;
        $practicalTotal = $practicalMid + $practicalQuiz + $practicalFinal;
    }

    /*
    =====================================
    TOTAL
    =====================================
    */

    $grandTotal = $theoryTotal + $practicalTotal;
    $cp = $grandTotal / 10;

    /*
    =====================================
    RESULT LOGIC (FIXED)
    =====================================
    */

    if ($subject->type == "Practical") {

        if ($grandTotal >= $requiredMarks) {
            $resultStatus = 'PASS';
            $resultColor  = 'green';
        } else {
            $resultStatus = 'FAIL';
            $resultColor  = 'red';
        }

    } else {

        if ($grandTotal >= $requiredMarks && $final >= $theoryMinMarks) {

            $resultStatus = 'PASS';
            $resultColor  = 'green';

        } elseif ($final > 0 && $final >= $theoryMinMarks) {
            // ✅ FIX: final > 0 added (SUPPLE bug solved)

            $resultStatus = 'SUPPLE';
            $resultColor  = 'orange';

        } else {

            $resultStatus = 'FAIL';
            $resultColor  = 'red';
        }
    }

    @endphp

    <tr>

        <td>{{ $key + 1 }}</td>

        <td class="student-name">
            {{ $student->student_name }}
        </td>

        <td>{{ $student->university_roll_no }}</td>

        <td>
            @if($resultStatus == 'PASS')
                <strong>{{ number_format($cp, 3) }}</strong>
                <br>
                <small style="color:green;">PASS</small>
            @else
                <strong style="color:{{ $resultColor }}">
                    {{ $resultStatus }}
                </strong>
                <br>
                <small>{{ number_format($cp, 3) }}</small>
            @endif
        </td>

        <td>{{ number_format($mid, 2) }}</td>
        <td>{{ number_format($quiz, 2) }}</td>
        {{-- <td>{{ number_format($final, 2) }}</td> --}}
        <td>

            {{ number_format($final, 2) }}

            @if($endFinalGrace > 0)

                <br>

                <small>
                    ({{ $endFinalOriginal }} + {{ $endFinalGrace }})
                </small>

            @endif

        </td>
        <td>{{ number_format($theoryTotal, 2) }}</td>

        <td>{{ number_format($practicalMid, 2) }}</td>
        <td>{{ number_format($practicalQuiz, 2) }}</td>
        {{-- <td>{{ number_format($practicalFinal, 2) }}</td> --}}
        <td>

            {{ number_format($practicalFinal, 2) }}

            @if($endFinalGrace > 0 && $subject->type != "Theory")

                <br>

                <small>
                    ({{ $endFinalOriginal }} + {{ $endFinalGrace }})
                </small>

            @endif

        </td>
        <td>{{ number_format($practicalTotal, 2) }}</td>

        <td>{{ number_format($grandTotal, 2) }}</td>

    </tr>

@endif

@endforeach

</tbody>

<tfoot>
<tr>
<td colspan="4" class="align-left">
    Prepared by
    <br><br><br>
    Checked by
</td>

<td colspan="4">
    Controller of Examinations
</td>

<td colspan="5" class="align-right">
    Registrar, Guru Angad Dev Veterinary <br>
    and Animal Science University
</td>
</tr>
</tfoot>

</table>