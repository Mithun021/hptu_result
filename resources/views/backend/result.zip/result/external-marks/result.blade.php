<style>
    table.result-table {
        width: 100%;
        border-collapse: collapse;
    }

    table.result-table th,
    table.result-table td {
        border: 1px solid #ddd;
        padding: 6px;
        text-align: center;
        font-size: 10px;
    }

    .marks-input {
        width: 60px;
        text-align: center;
    }
    .small-checkbox{
        transform: scale(0.7);
    }
    .lock-label{
        font-size:9px;
        display:inline-flex;
        align-items:center;
        gap:3px;
    }
    .marks-input::-webkit-outer-spin-button,
    .marks-input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    /* Firefox */
    .marks-input[type=number] {
        -moz-appearance: textfield;
    }
</style>

<div class="table-responsive">

@php
// ✅ ADDON: Filter subjects (UG → hide Practical)
$filteredSubjects = $subjects->filter(function($sub) use ($course) {
    return !($course->course == 'UG' && $sub->type == 'Practical');
});
@endphp

<table class="result-table">

    <thead>

        <tr>
            <td colspan="{{ 3 + $filteredSubjects->count() }}">

                <center>
                    <h4>OFFICES OF CONTROLLER OF EXAMINATIONS</h4>
                    <h4>GURU ANGAD DEV VETERINARY & ANIMAL SCIENCES</h4>

                    <p style="font-size:12px;font-weight:bold;">
                        {{ $exam->exam_resultsheet_name }}
                    </p>
                </center>

                <p style="text-align:left;margin:0;">
                    <b>
                        Class :
                        {{ $className }} {{ $course->name }}

                        @if(isset($branch) && $branch->name != 'NA')
                            / {{ $branch->name }}
                        @endif
                    </b>
                </p>

            </td>
        </tr>

        <tr>

            <th rowspan="3">SL</th>
            <th rowspan="3">Student Name</th>
            <th rowspan="3">Admission No</th>

            @foreach($filteredSubjects as $subject)
                <th>
                    {{ $subject->type }}
                </th>
            @endforeach

        </tr>

        <tr>
            @foreach($filteredSubjects as $subject)
                <th>
                    Sub : {{ $subject->subject_code }}
                </th>
            @endforeach
        </tr>

        <tr>
            @foreach($filteredSubjects as $subject)
                <th>
                    Max : {{ $subject->external_marks ?? '-' }}
                </th>
            @endforeach
        </tr>

    </thead>

    <tbody>

        @foreach($students as $studentIndex => $student)

            <tr>

                <td>
                    <input type="checkbox"
                    class="row-check no-export"
                    data-student="{{ $student->id }}">

                    {{ $studentIndex + 1 }}
                </td>

                <td>{{ $student->student_name }}</td>

                <td>{{ $student->university_roll_no }}</td>

                {{-- @foreach($filteredSubjects as $subject)

                    @php
                        $markData = $marks[$student->id][$subject->id] ?? null;

                        $obtained = $markData['obtained_marks'] ?? '';
                        $status   = $markData['exam_status'] ?? 'present';
                        $isLocked = $markData['is_locked'] ?? 0;
                    @endphp

                    <td>

                        @if($isLocked == 1)

                            @if($status == 'absent')
                                <span class="text-danger">AB</span>
                            @else
                                {{ $obtained }}
                            @endif

                        @else

                            <input
                                type="number"
                                class="marks-input save-marks no-export"
                                data-student="{{ $student->id }}"
                                data-subject="{{ $subject->id }}"
                                data-max="{{ $subject->external_marks }}"
                                value="{{ $status == 'absent' ? 0 : $obtained }}"
                                max="{{ $subject->external_marks }}"
                            >

                            <br>

                            <label style="font-size:9px" class="no-export lock-label">

                                <input
                                    type="checkbox"
                                    class="mark-absent small-checkbox"
                                    data-student="{{ $student->id }}"
                                    data-subject="{{ $subject->id }}"
                                    value="1"
                                    @if($status == 'absent') checked @endif
                                >

                                Absent

                            </label>

                        @endif

                        <br>

                        <label class="no-export lock-label">

                            <input
                                type="checkbox"
                                class="lock-check small-checkbox"
                                data-student="{{ $student->id }}"
                                data-subject="{{ $subject->id }}"
                            >

                            @if($isLocked == 1)
                                Unlock
                            @else
                                Lock
                            @endif

                        </label>

                    </td>

                @endforeach --}}

                @foreach($filteredSubjects as $subject)

                    @php
                        $markData = $marks[$student->id][$subject->id] ?? null;

                        $obtained = $markData['obtained_marks'] ?? '';
                        $status   = $markData['exam_status'] ?? 'present';
                        $isLocked = $markData['is_locked'] ?? 0;

                        // ✅ ADDED: Enrollment check
                        $isEnrolled = isset($studentSubjects[$student->id]) &&
                                    in_array($subject->id, $studentSubjects[$student->id]);
                    @endphp

                    <td>

                        @if(!$isEnrolled)
                            {{-- ✅ NOT ENROLLED --}}
                            <span class="text-muted">NA</span>

                        @elseif($isLocked == 1)

                            {{-- ✅ LOCKED VIEW --}}
                            @if($status == 'absent')
                                <span class="text-danger">AB</span>
                            @else
                                {{ $obtained }}
                            @endif

                        @else

                            {{-- ✅ EDIT MODE --}}
                            <input
                                type="number"
                                class="marks-input save-marks no-export"
                                data-student="{{ $student->id }}"
                                data-subject="{{ $subject->id }}"
                                data-max="{{ $subject->external_marks }}"
                                value="{{ $status == 'absent' ? 0 : $obtained }}"
                                max="{{ $subject->external_marks }}"
                            >

                            <br>

                            <label style="font-size:9px" class="no-export lock-label">

                                <input
                                    type="checkbox"
                                    class="mark-absent small-checkbox"
                                    data-student="{{ $student->id }}"
                                    data-subject="{{ $subject->id }}"
                                    value="1"
                                    @if($status == 'absent') checked @endif
                                >

                                Absent

                            </label>

                        @endif

                        @if($isEnrolled)
                            {{-- ✅ LOCK CHECK ONLY FOR ENROLLED --}}
                            <br>

                            <label class="no-export lock-label">

                                <input
                                    type="checkbox"
                                    class="lock-check small-checkbox"
                                    data-student="{{ $student->id }}"
                                    data-subject="{{ $subject->id }}"
                                >

                                @if($isLocked == 1)
                                    Unlock
                                @else
                                    Lock
                                @endif

                            </label>
                        @endif

                    </td>

                @endforeach

            </tr>

        @endforeach

    </tbody>

</table>

</div>