<style>
    table.dmc-table::before{
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;

        border: 1px solid #000;

        /* 🔥 WATERMARK IMAGE */
        background-image: url("{{ asset('assets/images/watermark.png') }}");
        background-repeat: no-repeat;
        background-position: center;
        background-size: 500px; /* ya contain / cover */

        opacity: 0.08; /* light watermark */

        pointer-events: none;
    }
    table.dmc-table {
        border: 0px;
        border-collapse: collapse;
        width: 100%;
        font-size: 14px;
    }
    table.dmc-table thead tr td{
        font-weight: bold;
    }
    table.dmc-table thead .header_info{
        display: flex;
        justify-content: space-between;
        margin-top: 10px;
    }
    table.dmc-table thead .header_info .personal-detail{
        width: 50%;
        font-weight: inherit;
    }
    table.dmc-table tbody{
        border-bottom: 1px solid #000 !important;
    }
    table.dmc-table tbody tr td{
        border: none !important;
    }
    table.dmc-table tfoot tr td{
        border: none !important;
    }
    table.dmc-table tfoot tr.bottom-signature td{
        padding-top: 60px;
    }
    table.dmc-table tfoot tr.bottom-signature td.text-right{
        text-align : right;
    }
    tr.top-bottom-border{
        border-top: 1px solid #000 !important;
        border-bottom: 1px solid #000 !important;
    }
</style>
<div class="dmc-sheet table-responsive">
    <table class="table dmc-table dmc-result-table">
        <thead class="table-header">
            <tr>
                <td colspan="6">
                    <center>
                        <h4>GURU ANGAD DEV VETERINARY AND ANIMAL SCIENCES UNIVERSITY, LUDHIANA (INDIA)</h4>
                    </center>
                    <div class="header_info">
                        <div class="personal-detail">
                            <span>Name:</span>
                            <b>Mithun Kumar</b>
                        </div>
                        <div class="personal-detail">
                            <span>Admn. No:</span>
                            <b>L-2024-BT-01-B</b>
                        </div>
                    </div>
                    <div class="header_info">
                        <div class="personal-detail">
                            <span>Semt:</span>
                            <b>2024-25 1(1)</b>
                        </div>
                        <div class="personal-detail">
                            <span>Subject:</span>
                            <b>B. Tech. (Biotechnology)</b>
                        </div>
                    </div>
                </td>
            </tr>
            <tr><td colspan="6" class="spacing"></td></tr>
            <tr class="top-bottom-border">
                <td width="10%">Sr.No</td>
                <td colspan="2" width="50%">Course Title</td>
                <td width="20%">Course No.</td>
                <td width="10%">Cr.Hr. </td>
                <td width="10%">Cr.Pts.</td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td colspan="2">Cell Biology</td>
                <td>Biotech. 101</td>
                <td>2</td>
                <td>Fail</td>
            </tr>
            <tr>
                <td>2</td>
                <td colspan="2">Cell Biology</td>
                <td>Biotech. 101</td>
                <td>2</td>
                <td>Fail</td>
            </tr>
            <tr>
                <td>3</td>
                <td colspan="2">Cell Biology</td>
                <td>Biotech. 101</td>
                <td>2</td>
                <td>Fail</td>
            </tr>
            <tr>
                <td>4</td>
                <td colspan="2">Cell Biology</td>
                <td>Biotech. 101</td>
                <td>2</td>
                <td>Fail</td>
            </tr>
            <tr>
                <td>5</td>
                <td colspan="2">Cell Biology</td>
                <td>Biotech. 101</td>
                <td>2</td>
                <td>Fail</td>
            </tr>
            <tr>
                <td>6</td>
                <td colspan="2">Cell Biology</td>
                <td>Biotech. 101</td>
                <td>2</td>
                <td>Fail</td>
            </tr>
            <tr>
                <td>7</td>
                <td colspan="2">Cell Biology</td>
                <td>Biotech. 101</td>
                <td>2</td>
                <td>Fail</td>
            </tr>
            <tr>
                <td>8</td>
                <td colspan="2">Cell Biology</td>
                <td>Biotech. 101</td>
                <td>2</td>
                <td>Fail</td>
            </tr>
            <tr>
                <td>9</td>
                <td colspan="2">Cell Biology</td>
                <td>Biotech. 101</td>
                <td>2</td>
                <td>Fail</td>
            </tr>
            <tr>
                <td>10</td>
                <td colspan="2">Cell Biology</td>
                <td>Biotech. 101</td>
                <td>2</td>
                <td>Fail</td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2">Total Cr Hrs: 16</td>
                <td colspan="2">Total Cr Pts. : 63.48</td>
                <td colspan="2">CPA: 3.968</td>
            </tr>
            <tr>
                <td colspan="2">TPrev Cr Hrs: 0</td>
                <td colspan="4">Prev Cr Pts. : 0.00</td>
            </tr>
            <tr>
                <td colspan="2">Less Cr Hrs: 0</td>
                <td colspan="4">Less Cr Pts. : 0.00 For Repeating</td>
            </tr>
            <tr>
                <td colspan="2">Cumu Cr Hrs: 16</td>
                <td colspan="2">Cumu Cr Pts. : 63.48</td>
                <td colspan="2">OCPA: 3.968</td>
            </tr>
            <tr>
                <td colspan="6">Overall Performance : <b>SCHOLASTIC PROBATION</b></td>
            </tr>
            <tr class="bottom-signature">
                <td colspan="3">Date: 15-1-2025</td>
                <td colspan="3" class="text-right">Registrar</td>
            </tr>
        </tfoot>
    </table>
</div>